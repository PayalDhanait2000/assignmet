const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());


app.get('/api/menu',(req,res)=>{
    
});

app.post('/api/cart',(req,res)=>{
    const cartItems = db.cartItems.map((item)=>{
        const menuItem = db.menuItems.find((menu)=>menu.id === item.itemId);
        return{
            ...item,
            name:menuItem.name,
            price:menuItem.price
        };
    });
    res.json(cartItems);
});
app.post('/api/cart',(req,res)=>{
    
});

app.get('/api/bill',(req,res)=>{
    const cartItems = db.cartItems;
    let totalAmount =0;
    for(const item of cartItems){
        const menuItem = db.menuItems.find((menu)=>menu.id === item.itemId);
        totalamount += menuItem.price * item.quantity;
    }
    res.json({totalAmount});
});

const port =3000;
app.listen(port,()=>{
    console.log('server running at port 3000');
});