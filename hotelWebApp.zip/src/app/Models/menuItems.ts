export interface menuItems
{
    id:number,
    name:string,
    price:number
}