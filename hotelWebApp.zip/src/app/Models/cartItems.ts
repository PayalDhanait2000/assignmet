export interface cartItems
{
    id:number,
    name:string,
    price:number
}