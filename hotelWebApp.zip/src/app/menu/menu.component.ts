import { Component,OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { response } from 'express';
import{Observable} from 'rxjs';
import { menuItems } from '../Models/menuItems';
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit{
  menuItems:menuItems[] = [] ;

  constructor(private apiService:ApiService){}

ngOnInit(){
 this.getMenuItems();
}
getMenuItems()
 {
  let observable = this.getMenuItems();
  observable.subscribe((data:menuItems[])=>{
    this.empList=data;
  })
 }
addToCart(item:any){
  this.apiService.addToCart(item).subscribe(
    (response)=>{
      console.log('Item added to cart:',response);
    },
    (error)=>{
      console.log(error);
    }
  );
}

}
